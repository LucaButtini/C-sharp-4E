﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mosca
{
    public partial class GiocoVisuale : Form
    {
        Point xy;
        Random pos = new Random();
        string path = Environment.CurrentDirectory + "\\mosca_immagini";
        public GiocoVisuale()
        {
            xy = new Point();
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rMosca.Checked = true; //genera automaticamente 

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            xy.X = pos.Next(0, (Area.ClientSize.Width - Bug.Width) + 1);
            xy.Y = pos.Next(0, (Area.ClientSize.Height - Bug.Height) + 1);
            Bug.Location = xy;
        }

        private void Bug_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            Bug.Image = Image.FromFile(path + "\\moscaX.gif");
            MessageBox.Show("Colpita", "DON POLLO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            timer1.Enabled = true;
            Bug.Image = Image.FromFile(path + "\\mosca.gif");
        }

        private void rApe_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rMosca_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Evento generato");
        }
    }
}
