﻿namespace Mosca
{
    partial class GiocoVisuale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnClose = new System.Windows.Forms.Button();
            this.Area = new System.Windows.Forms.Panel();
            this.Bug = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.grBugs = new System.Windows.Forms.GroupBox();
            this.rMosca = new System.Windows.Forms.RadioButton();
            this.rRagni = new System.Windows.Forms.RadioButton();
            this.rFarfalla = new System.Windows.Forms.RadioButton();
            this.rApe = new System.Windows.Forms.RadioButton();
            this.Area.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Bug)).BeginInit();
            this.grBugs.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(772, 415);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.button1_Click);
            // 
            // Area
            // 
            this.Area.BackgroundImage = global::Mosca.Properties.Resources.prato2;
            this.Area.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Area.Controls.Add(this.Bug);
            this.Area.Location = new System.Drawing.Point(12, 5);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(722, 404);
            this.Area.TabIndex = 1;
            this.Area.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Bug
            // 
            this.Bug.BackColor = System.Drawing.Color.Transparent;
            this.Bug.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Bug.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Bug.Image = global::Mosca.Properties.Resources.mosca;
            this.Bug.Location = new System.Drawing.Point(567, 139);
            this.Bug.Name = "Bug";
            this.Bug.Size = new System.Drawing.Size(70, 74);
            this.Bug.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bug.TabIndex = 0;
            this.Bug.TabStop = false;
            this.Bug.Click += new System.EventHandler(this.Bug_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // grBugs
            // 
            this.grBugs.Controls.Add(this.rMosca);
            this.grBugs.Controls.Add(this.rRagni);
            this.grBugs.Controls.Add(this.rFarfalla);
            this.grBugs.Controls.Add(this.rApe);
            this.grBugs.Location = new System.Drawing.Point(740, 118);
            this.grBugs.Name = "grBugs";
            this.grBugs.Size = new System.Drawing.Size(123, 138);
            this.grBugs.TabIndex = 3;
            this.grBugs.TabStop = false;
            this.grBugs.Text = "SELEZIONAZIONE";
            // 
            // rMosca
            // 
            this.rMosca.AutoSize = true;
            this.rMosca.Location = new System.Drawing.Point(7, 98);
            this.rMosca.Name = "rMosca";
            this.rMosca.Size = new System.Drawing.Size(57, 17);
            this.rMosca.TabIndex = 3;
            this.rMosca.TabStop = true;
            this.rMosca.Text = "Mosca";
            this.rMosca.UseVisualStyleBackColor = true;
            this.rMosca.CheckedChanged += new System.EventHandler(this.rMosca_CheckedChanged);
            // 
            // rRagni
            // 
            this.rRagni.AutoSize = true;
            this.rRagni.Location = new System.Drawing.Point(7, 74);
            this.rRagni.Name = "rRagni";
            this.rRagni.Size = new System.Drawing.Size(57, 17);
            this.rRagni.TabIndex = 2;
            this.rRagni.TabStop = true;
            this.rRagni.Text = "Ragno";
            this.rRagni.UseVisualStyleBackColor = true;
            this.rRagni.CheckedChanged += new System.EventHandler(this.rMosca_CheckedChanged);
            // 
            // rFarfalla
            // 
            this.rFarfalla.AutoSize = true;
            this.rFarfalla.Location = new System.Drawing.Point(7, 50);
            this.rFarfalla.Name = "rFarfalla";
            this.rFarfalla.Size = new System.Drawing.Size(59, 17);
            this.rFarfalla.TabIndex = 1;
            this.rFarfalla.TabStop = true;
            this.rFarfalla.Text = "Farfalla";
            this.rFarfalla.UseVisualStyleBackColor = true;
            this.rFarfalla.CheckedChanged += new System.EventHandler(this.rMosca_CheckedChanged);
            // 
            // rApe
            // 
            this.rApe.AutoSize = true;
            this.rApe.Location = new System.Drawing.Point(7, 26);
            this.rApe.Name = "rApe";
            this.rApe.Size = new System.Drawing.Size(44, 17);
            this.rApe.TabIndex = 0;
            this.rApe.TabStop = true;
            this.rApe.Text = "Ape";
            this.rApe.UseVisualStyleBackColor = true;
            this.rApe.CheckedChanged += new System.EventHandler(this.rMosca_CheckedChanged);
            // 
            // GiocoVisuale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 450);
            this.Controls.Add(this.grBugs);
            this.Controls.Add(this.Area);
            this.Controls.Add(this.btnClose);
            this.Name = "GiocoVisuale";
            this.Text = "Tiro_a_Segno";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Area.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Bug)).EndInit();
            this.grBugs.ResumeLayout(false);
            this.grBugs.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel Area;
        private System.Windows.Forms.PictureBox Bug;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox grBugs;
        private System.Windows.Forms.RadioButton rMosca;
        private System.Windows.Forms.RadioButton rRagni;
        private System.Windows.Forms.RadioButton rFarfalla;
        private System.Windows.Forms.RadioButton rApe;
    }
}

